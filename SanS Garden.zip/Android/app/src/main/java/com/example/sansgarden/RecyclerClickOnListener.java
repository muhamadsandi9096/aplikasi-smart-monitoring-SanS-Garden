package com.example.sansgarden;

public interface RecyclerClickOnListener {
    void onItemClicked(ArtikelModel artikelModel);
}
